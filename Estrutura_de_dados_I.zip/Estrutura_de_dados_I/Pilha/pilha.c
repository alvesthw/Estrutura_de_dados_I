#include <iostream>
#include <cstdlib>
#include <string>
#include <cstring>

// Definições da pilha (como no código anterior)
typedef struct No {
    char prato[50];
    struct No* prox;
    struct No* ant;
} No;

typedef struct {
    No* topo;
} Pilha;

// Funções da pilha
void inicializar(Pilha* p) {
    p->topo = NULL;
}

bool seVazia(Pilha* p) {
    return p->topo == NULL;
}

void empilhar(Pilha* p, const char* valor) {
    No* novo = (No*)malloc(sizeof(No));
    if (!novo) {
        std::cout << "Erro: memória insuficiente!" << std::endl;
        return;
    }
    strcpy(novo->prato, valor);
    novo->prox = NULL;
    novo->ant = p->topo;

    if (p->topo != NULL)
        p->topo->prox = novo;

    p->topo = novo;
}

char* desenpilhar(Pilha* p) {
    if (seVazia(p)) {
        std::cout << "Erro: pilha vazia!" << std::endl;
        return NULL;
    }
    No* remover = p->topo;
    static char valor[50];
    strcpy(valor, remover->prato);

    p->topo = remover->ant;
    if (p->topo != NULL)
        p->topo->prox = NULL;

    free(remover);
    return valor;
}

char* mostraTopo(Pilha* p) {
    if (seVazia(p)) {
        std::cout << "Pilha vazia!" << std::endl;
        return NULL;
    }
    return p->topo->prato;
}

void exibirTopoParaBase(Pilha* p) {
    if (seVazia(p)) {
        std::cout << "Pilha vazia" << std::endl;
        return;
    }
    std::cout << "Pilha (topo -> base): ";
    No* aux = p->topo;
    while (aux != NULL) {
        std::cout << aux->prato << " ";
        aux = aux->ant;
    }
    std::cout << std::endl;
}

void exibirBaseParaTopo(Pilha* p) {
    if (seVazia(p)) {
        std::cout << "Pilha vazia" << std::endl;
        return;
    }
    No* aux = p->topo;
    while (aux != NULL && aux->ant != NULL) {
        aux = aux->ant;
    }

    std::cout << "Pilha (base -> topo): ";
    while (aux != NULL) {
        std::cout << aux->prato << " ";
        aux = aux->prox;
    }
    std::cout << std::endl;
}

// Função do menu interativo
void menu() {
    Pilha pratos;
    inicializar(&pratos);

    int opcao;
    char prato[50];

    do {
        std::cout << "\n--- Menu ---\n";
        std::cout << "1. Empilhar prato\n";
        std::cout << "2. Desempilhar prato\n";
        std::cout << "3. Mostrar prato do topo\n";
        std::cout << "4. Exibir pilha (topo -> base)\n";
        std::cout << "5. Exibir pilha (base -> topo)\n";
        std::cout << "0. Sair\n";
        std::cout << "Escolha uma opcao: ";
        std::cin >> opcao;
        std::cin.ignore(); // Limpar o buffer de entrada

        switch(opcao) {
            case 1:
                std::cout << "Digite o nome do prato para empilhar: ";
                std::cin.getline(prato, sizeof(prato));
                empilhar(&pratos, prato);
                break;
            case 2:
                {
                    char* removido = desenpilhar(&pratos);
                    if (removido != NULL)
                        std::cout << "Prato desempilhado: " << removido << std::endl;
                }
                break;
            case 3:
                {
                    char* topo = mostraTopo(&pratos);
                    if (topo != NULL)
                        std::cout << "Prato do topo: " << topo << std::endl;
                }
                break;
            case 4:
                exibirTopoParaBase(&pratos);
                break;
            case 5:
                exibirBaseParaTopo(&pratos);
                break;
            case 0:
                std::cout << "Saindo..." << std::endl;
                break;
            default:
                std::cout << "Opcao invalida! Tente novamente." << std::endl;
        }

    } while(opcao != 0);
}

int main() {
    menu();
    return 0;
}
