#include <stdio.h>
#include <stdlib.h>

// Estrutura de Produto 
typedef struct produto {
    int id;
    char nome[99];
} Produto;

// Estrutura do Nó
typedef struct no {
    Produto produto; 
    struct no* proximo;
    struct no* anterior;
} No;

// Estrutura da Lista
typedef struct lista {
    No* cabeca;
    No* cauda;
} Lista;

// Função para criar um nó
No* criarNo(Produto produto) {
    No* novo = (No*)malloc(sizeof(No));
    if (!novo) {
        printf("Erro ao alocar memória\n");
        exit(1);
    }
    novo->produto = produto;
    novo->proximo = NULL;
    novo->anterior = NULL;
    return novo;
}

// Adicionar nó ao final da lista
void adicionarNo(Lista* lista, Produto produto) {
    No* novo = criarNo(produto);
    if (lista->cabeca == NULL) {
        lista->cabeca = novo;
        lista->cauda = novo;
    } else {
        novo->anterior = lista->cauda;
        lista->cauda->proximo = novo;
        lista->cauda = novo;
    }
}

// Adicionar nó no início da lista
void adicionarNoInicio(Lista* lista, Produto produto) {
    No* novo = criarNo(produto);
    if (lista->cabeca == NULL) {
        lista->cabeca = novo;
        lista->cauda = novo;
    } else {
        novo->proximo = lista->cabeca;
        lista->cabeca->anterior = novo;
        lista->cabeca = novo;
    }
}

// Função para remover nó do final
void removerNoFim(Lista* lista) {
    if (lista->cauda == NULL) {
        printf("A lista está vazia\n");
        return;
    }
    No* removido = lista->cauda;
    if (lista->cabeca == lista->cauda) { // Se há apenas um nó
        lista->cabeca = NULL;
        lista->cauda = NULL;
    } else {
        lista->cauda = removido->anterior;
        lista->cauda->proximo = NULL;
    }
    free(removido);
}

// Percorrer a lista (cabeça -> cauda)
void imprimirLista(Lista* lista) {
    No* atual = lista->cabeca;
    while (atual != NULL) {
        printf("ID: %d, Nome: %s -> ", atual->produto.id, atual->produto.nome);
        atual = atual->proximo;
    }
    printf("NULL\n");
}

// Percorrer a lista (cauda -> cabeça)
void imprimirListaReversa(Lista* lista) {
    No* atual = lista->cauda;
    while (atual != NULL) {
        printf("ID: %d, Nome: %s -> ", atual->produto.id, atual->produto.nome);
        atual = atual->anterior;
    }
    printf("NULL\n");
}

// Liberar memoria
void liberarLista(Lista* lista) {
    No* atual = lista->cabeca;
    while (atual != NULL) {
        No* tmp = atual;
        atual = atual->proximo;
        free(tmp);
    }
    lista->cabeca = NULL;
    lista->cauda = NULL;
}

// Buscar um produto na lista
No* buscarProduto(Lista* lista, int id) {
    No* atual = lista->cabeca;
    while (atual != NULL) {
        if (atual->produto.id == id) {
            return atual;
        }
        atual = atual->proximo;
    }
    return NULL; // Não achou
}

int main() {
    Lista lista = {NULL, NULL};

    Produto p1 = {1, "Cafe"};
    Produto p2 = {2, "Cha"};
    Produto p3 = {3, "Agua"};

    adicionarNo(&lista, p1);
    adicionarNo(&lista, p2);
    adicionarNo(&lista, p3);

    imprimirLista(&lista);
    imprimirListaReversa(&lista);

    Produto p4 = {4, "Suco"};
    adicionarNoInicio(&lista, p4);

    imprimirLista(&lista);
    
    removerNoFim(&lista);
    imprimirLista(&lista);

    No* encontrado = buscarProduto(&lista, 2);
    if (encontrado) {
        printf("Produto encontrado: ID: %d, Nome: %s\n", encontrado->produto.id, encontrado->produto.nome);
    } else {
        printf("Produto não encontrado.\n");
    }

    liberarLista(&lista);
    return 0;
}
